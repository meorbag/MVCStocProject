﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcStok.Models.Entity;

namespace MvcStok.Controllers
{
    public class MusteriController : Controller
    {
        // GET: Musteri
        MvcDbStokEntities db = new MvcDbStokEntities();
        public ActionResult Index(string p1)
        {
            var musteriler = from d in db.TBLMUSTERILER select d;
            if (!string.IsNullOrEmpty(p1))
            {
                musteriler = musteriler.Where(m => m.MUSTERIAD.Contains(p1));
            }
            return View(musteriler.ToList());
            //var musteriler = db.TBLMUSTERILER.ToList();
            //return View(musteriler);
        }

        [HttpGet]
        public ActionResult NewCustomer()
        {
            return View();
        }

        [HttpPost]
        public ActionResult NewCustomer(TBLMUSTERILER p1)
        {
            db.TBLMUSTERILER.Add(p1);
            db.SaveChanges();
            return View();
        }
        public ActionResult Deletion(int id)
        {
            var musteri = db.TBLMUSTERILER.Find(id);
            db.TBLMUSTERILER.Remove(musteri);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult EditCustomer(int id)
        {
            var cust = db.TBLMUSTERILER.Find(id);
            return View("EditCustomer", cust);
        }
        public ActionResult Guncelle(TBLMUSTERILER p1)
        {
            var cust = db.TBLMUSTERILER.Find(p1.MUSTERIID);
            cust.MUSTERIAD = p1.MUSTERIAD;
            cust.MUSTERISOYAD = p1.MUSTERISOYAD;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}