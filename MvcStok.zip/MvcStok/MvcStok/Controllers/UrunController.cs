﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcStok.Models.Entity;

namespace MvcStok.Controllers
{
    public class UrunController : Controller
    {
        // GET: Urun
        MvcDbStokEntities db = new MvcDbStokEntities();
        public ActionResult Index()
        {
            var urunler = db.TBLURUNLER.ToList();
            return View(urunler);
        }
        [HttpGet]
        public ActionResult NewProduct()
        {
            List<SelectListItem> urunlr = (from i in db.TBLKATEGORILER.ToList()
                                           select new SelectListItem
                                           {
                                               Text = i.KATEGORIAD,
                                               Value = i.KATEGORIID.ToString()
                                           }).ToList();
            ViewBag.deger = urunlr;
            return View();
        }

        [HttpPost]
        public ActionResult NewProduct(TBLURUNLER p1)
        {
            var ctg = db.TBLKATEGORILER.Where(m => m.KATEGORIID == p1.TBLKATEGORILER.KATEGORIID).FirstOrDefault();
            p1.TBLKATEGORILER = ctg;
            db.TBLURUNLER.Add(p1);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Deletion(int id)
        {
            var urun = db.TBLURUNLER.Find(id);
            db.TBLURUNLER.Remove(urun);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult EditProduct(int id)
        {
            var urun = db.TBLURUNLER.Find(id);
            List<SelectListItem> urunlr = (from i in db.TBLKATEGORILER.ToList()
                                           select new SelectListItem
                                           {
                                               Text = i.KATEGORIAD,
                                               Value = i.KATEGORIID.ToString()
                                           }).ToList();
            ViewBag.deger = urunlr;
            return View("EditProduct", urun);
        }
        public ActionResult Guncelle(TBLURUNLER p1)
        {
            var cust = db.TBLURUNLER.Find(p1.URUNID);
            cust.URUNAD = p1.URUNAD;
            cust.MARKA = p1.MARKA;
            cust.FIYAT = p1.FIYAT;
            cust.STOK = p1.STOK;
            var ctg = db.TBLKATEGORILER.Where(m => m.KATEGORIID == p1.TBLKATEGORILER.KATEGORIID).FirstOrDefault();
            cust.URUNKATEGORI= ctg.KATEGORIID;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}