﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcStok.Models.Entity;
using PagedList;
using PagedList.Mvc;

namespace MvcStok.Controllers
{
    public class KategoriController : Controller
    {
        // GET: Kategori
        MvcDbStokEntities db = new MvcDbStokEntities();

        public ActionResult Index(int sayfa=1)
        {
            //var categories = db.TBLKATEGORILER.ToList();
            var categories = db.TBLKATEGORILER.ToList().ToPagedList(sayfa, 4);
            return View(categories);
        }
        [HttpGet]
        public ActionResult NewCategory()
        {
            return View();
        }

        [HttpPost]
        public ActionResult NewCategory(TBLKATEGORILER p1)
        {
            db.TBLKATEGORILER.Add(p1);
            db.SaveChanges();
            return View();
        }
        public ActionResult Deletion(int id)
        {
            var category = db.TBLKATEGORILER.Find(id);
            db.TBLKATEGORILER.Remove(category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult EditCategory(int id)
        {
            var ctg = db.TBLKATEGORILER.Find(id);
            return View("EditCategory",ctg);
        }

        public ActionResult Guncelle(TBLKATEGORILER p1)
        {
            var ctg = db.TBLKATEGORILER.Find(p1.KATEGORIID);
            ctg.KATEGORIAD = p1.KATEGORIAD;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}